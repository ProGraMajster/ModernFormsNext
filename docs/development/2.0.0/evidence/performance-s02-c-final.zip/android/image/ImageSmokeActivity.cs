using Android.App;
using Android.Content.PM;
using Android.Views;
using ModernFormsNext;
using ModernFormsNext.WindowKit.Backend.Android;
using ModernFormsNext.WindowKit.Backend.Android.Windowing;
using SkiaSharp;
using Mfn = ModernFormsNext.Application;

[Activity(Name="com.modernformsnext.skiaqualification.image.ImageSmokeActivity",
    MainLauncher=true, Exported=true, ConfigurationChanges=ConfigChanges.Orientation|ConfigChanges.ScreenSize)]
public sealed class ImageSmokeActivity : AndroidWindowActivity
{
    private SKBitmap? image;

    protected override void OnStartApplication()
    {
        Window!.AddFlags(WindowManagerFlags.KeepScreenOn);
        using var pattern = new SKBitmap(64,64);
        using (var canvas = new SKCanvas(pattern))
        using (var paint = new SKPaint { Color = new SKColor(25,185,125) })
        {
            canvas.Clear(new SKColor(240,104,42));
            canvas.DrawRect(16,16,32,32,paint);
        }
        using var png = pattern.Encode(SKEncodedImageFormat.Png,100);
        image = SKBitmap.Decode(png);
        if (image.GetPixel(0,0) != new SKColor(240,104,42) || image.GetPixel(32,32) != new SKColor(25,185,125))
            throw new InvalidOperationException("PNG pixels did not survive the round trip.");
        var window = new Form();
        window.Controls.Add(new Label { Bounds = new(20,110,290,34), Text = "PNG • Zażółć • 中文 • 😀" });
        window.Controls.Add(new PictureBox { Bounds = new(20,155,190,190), Image = image, SizeMode = PictureBoxSizeMode.Zoom });
        Android.Util.Log.Info("MfnImageSmoke", $"Decoded PNG with native Skia {SkiaSharpVersion.Native}");
        Mfn.Run(window);
    }

    protected override void OnDestroy()
    {
        base.OnDestroy();
        image?.Dispose();
    }
}

[Application]
public sealed class ImageSmokeApplication(IntPtr handle, Android.Runtime.JniHandleOwnership ownership)
    : Android.App.Application(handle,ownership)
{
    public override void OnCreate()
    {
        base.OnCreate();
        Mfn.ConfigureRendering(new RenderingOptions { Backend = RenderingBackend.Software });
        AndroidWindowKit.Initialize(new AndroidWindowKitOptions(this));
    }
}
