from pathlib import Path
from datetime import datetime, timezone
import csv, hashlib, json, os, shutil, subprocess, sys, threading, time
import psutil

stage, out = map(Path, sys.argv[1:])
lab = stage / 'benchmark-pair'
assemblies = {leg: lab / leg / 'ModernFormsNext.PerformanceLab.dll' for leg in ['3x', '4x']}
stop = threading.Event()
def now(): return datetime.now(timezone.utc).isoformat()
phase = 'preflight'

def sample():
    previous = {}
    stamp = time.monotonic()
    psutil.cpu_percent()
    with (out/'cpu.jsonl').open('w', encoding='utf-8') as stream:
        while not stop.wait(1.0):
            new = {}
            top = []
            instant = time.monotonic()
            for p in psutil.process_iter(['name', 'cpu_times']):
                t = p.info['cpu_times']
                if t is not None:
                    key = p.pid, p.info['name']
                    new[key] = t.user + t.system
                    if key in previous:
                        top.append((round(100*(new[key]-previous[key])/(instant-stamp)/psutil.cpu_count(),2),key[1]))
            row = {'at':now(),'phase':phase,'totalPercent':psutil.cpu_percent(),'top':sorted(top,reverse=True)[:7]}
            stream.write(json.dumps(row)+'\n'); stream.flush()
            previous = new
            stamp = instant

monitor = threading.Thread(target=sample)
gpu = None
if shutil.which('nvidia-smi'):
    gpu_log = (out/'gpu.csv').open('w')
    gpu_err = (out/'gpu-stderr.log').open('w')
    gpu = subprocess.Popen(['nvidia-smi','--query-gpu=timestamp,name,temperature.gpu,utilization.gpu,power.draw','--format=csv','-l','1'],stdout=gpu_log,stderr=gpu_err,creationflags=subprocess.CREATE_NO_WINDOW)
monitor.start()
runs = []
files = {leg: {name: hashlib.sha256((dll.parent/name).read_bytes()).hexdigest()
               for name in (dll.name,'ModernFormsNext.dll','SkiaSharp.dll')}
         for leg,dll in assemblies.items()}
brief = {'artifacts':files, 'order':runs, 'temperatureCPU':'Direct CPU package sensor unavailable to runner', 'hostConfirmation':'Owner confirmed the workstation was free before this session.'}
try:
    time.sleep(5)
    preflight = [json.loads(line) for line in (out/'cpu.jsonl').read_text().splitlines() if line]
    # A sustained loaded host warrants a fresh window. Short excursions remain in the record.
    if len(preflight) < 3 or sum(d['totalPercent'] for d in preflight[-3:])/3 >= 20:
        raise RuntimeError(f'Host remained busy in preflight: {[d["totalPercent"] for d in preflight]}')
    for scenario, count in [('startup', 5),('virtualized-scroll',3)]:
        for trial in range(1, count+1):
            order = ['3x','4x'] if (trial+(scenario!='startup'))%2 else ['4x','3x']
            for leg in order:
                phase=f'{scenario}-{trial}-{leg}'
                run = {'id':phase,'startedUtc':now(),'stack':leg,'trial':trial,'scenario':scenario}
                data=out/phase
                with (out/(phase+'.log')).open('w') as log:
                    subprocess.run(['dotnet',str(assemblies[leg]),'--scenario',scenario,'--backend','software','--output',str(data)],
                                   check=True,timeout=25,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
                run['endedUtc']=now()
                run['resultSha256']=hashlib.sha256((data/'results.json').read_bytes()).hexdigest()
                runs.append(run)
                print(phase,flush=True)
    phase = 'postflight'
    time.sleep(2)
finally:
    stop.set()
    monitor.join()
    if gpu:
        gpu.terminate()
        gpu.wait(timeout=5)
        gpu_log.close()
        gpu_err.close()
    (out/'session.json').write_text(json.dumps(brief,indent=2),encoding='utf-8')
