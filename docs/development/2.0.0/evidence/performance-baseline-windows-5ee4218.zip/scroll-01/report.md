# ModernFormsNext PerformanceLab

Scenario: virtualized-scroll (collection-100k-fixed-56px-v1)
Recorded UTC: 2026-11-27T19:36:39.0122743+00:00
Lab build: 1.0.0+5ee4218fcb05b08e621915552fe64ef0d5aa2629
Framework build: 1.12.1+5ee4218fcb05b08e621915552fe64ef0d5aa2629
Runtime: .NET 10.0.15 X64
SkiaSharp: managed 3.119.2+release-3.119.2.2888c737ad016d584c74525e2d35db5097ea8576.2888c737ad016d584c74525e2d35db5097ea8576, native 119.0
OS: Microsoft Windows 10.0.26300
CPU: Intel(R) Core(TM) i9-14900K, 32 logical processors
Physical RAM: 65252.137 MiB
Display adapter: NVIDIA GeForce RTX 5090
Window DPI: 96
Windows-reported display mode: 144 Hz
Backend: Windows, requested Software, active Software

Main to Shown: 190.069 ms
Main to first complete native paint: 251.443 ms
Recorder-epoch bounds: 250.211–252.676 ms
Process window: 3303.519 ms, CPU 1359.375 ms (41.149% of one logical core)
Process working set: 88.082 MiB → 107.043 MiB
Process private memory: 50.063 MiB → 64.949 MiB
Managed process allocations: 32277568 B

| Retained observations | Samples | p50 | p95 | p99 |
| --- | ---: | ---: | ---: | ---: |
| Native paint wall time, ms | 120 | 3.498 | 5.659 | 9.054 |
| Layout wall time, ms | 120 | 0.176 | 0.418 | 0.586 |
| Framework render wall time, ms | 120 | 3.261 | 5.42 | 8.555 |
| Callback interval, ms | 119 | 29.642 | 33.539 | 36.787 |
| Native framebuffer submission wall time, ms | 120 | 0.165 | 0.287 | 0.43 |
| Managed UI-thread allocation, B | 120 | 238968 | 249432 | 362856 |
| GPU execution, ms | 0 | unavailable | unavailable | unavailable |

CollectionView: 100000 items, 120 measured offset updates of 56 logical px at a requested 16 ms interval
Viewport offset: 0 → 6720 logical px
Realized containers: 25 → 27
Container reuses in measured window: 240

Profiler phase timings are elapsed wall time. Layout and rendering can overlap other observations.
The framework render category includes software rendering and composition. Standalone raster timing is unavailable.
GDI submission is a CPU-side wall-time observation. Display-mode Hz and callback intervals do not measure scanout.
Actual compositor presentation and physical scanout are unavailable.
Raw recorder data, process counters, frame identifiers and versions are in results.json.
