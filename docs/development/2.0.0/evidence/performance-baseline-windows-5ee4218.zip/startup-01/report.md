# ModernFormsNext PerformanceLab

Scenario: startup (flow-96-controls-v1)
Recorded UTC: 2026-11-27T19:36:34.8883793+00:00
Lab build: 1.0.0+5ee4218fcb05b08e621915552fe64ef0d5aa2629
Framework build: 1.12.1+5ee4218fcb05b08e621915552fe64ef0d5aa2629
Runtime: .NET 10.0.15 X64
SkiaSharp: managed 3.119.2+release-3.119.2.2888c737ad016d584c74525e2d35db5097ea8576.2888c737ad016d584c74525e2d35db5097ea8576, native 119.0
OS: Microsoft Windows 10.0.26300
CPU: Intel(R) Core(TM) i9-14900K, 32 logical processors
Physical RAM: 65252.137 MiB
Display adapter: NVIDIA GeForce RTX 5090
Window DPI: 96
Windows-reported display mode: 144 Hz
Backend: Windows, requested Software, active Software

Main to Shown: 358.75 ms
Main to first complete native paint: 433.791 ms
Recorder-epoch bounds: 432.537–435.044 ms
Process window: 437.82 ms, CPU 265.625 ms (60.67% of one logical core)
Process working set: 26.148 MiB → 67.219 MiB
Process private memory: 7.512 MiB → 29.539 MiB
Managed process allocations: 4115192 B

| Retained observations | Samples | p50 | p95 | p99 |
| --- | ---: | ---: | ---: | ---: |
| Native paint wall time, ms | 1 | 64.845 | 64.845 | 64.845 |
| Layout wall time, ms | 1 | 18.677 | 18.677 | 18.677 |
| Framework render wall time, ms | 1 | 56.222 | 56.222 | 56.222 |
| Callback interval, ms | 0 | unavailable | unavailable | unavailable |
| Native framebuffer submission wall time, ms | 1 | 0.711 | 0.711 | 0.711 |
| Managed UI-thread allocation, B | 1 | 1455776 | 1455776 | 1455776 |
| GPU execution, ms | 0 | unavailable | unavailable | unavailable |

Profiler phase timings are elapsed wall time. Layout and rendering can overlap other observations.
The framework render category includes software rendering and composition. Standalone raster timing is unavailable.
GDI submission is a CPU-side wall-time observation. Display-mode Hz and callback intervals do not measure scanout.
Actual compositor presentation and physical scanout are unavailable.
Raw recorder data, process counters, frame identifiers and versions are in results.json.
