# ModernFormsNext PerformanceLab

Scenario: virtualized-scroll (collection-100k-fixed-56px-v1)
Recorded UTC: 2026-11-27T19:36:48.2402820+00:00
Lab build: 1.0.0+5ee4218fcb05b08e621915552fe64ef0d5aa2629
Framework build: 1.12.1+5ee4218fcb05b08e621915552fe64ef0d5aa2629
Runtime: .NET 10.0.15 X64
SkiaSharp: managed 3.119.2+release-3.119.2.2888c737ad016d584c74525e2d35db5097ea8576.2888c737ad016d584c74525e2d35db5097ea8576, native 119.0
OS: Microsoft Windows 10.0.26300
CPU: Intel(R) Core(TM) i9-14900K, 32 logical processors
Physical RAM: 65252.137 MiB
Display adapter: NVIDIA GeForce RTX 5090
Window DPI: 96
Windows-reported display mode: 144 Hz
Backend: Windows, requested Software, active Software

Main to Shown: 177.309 ms
Main to first complete native paint: 236.55 ms
Recorder-epoch bounds: 235.415–237.685 ms
Process window: 3407.074 ms, CPU 1765.625 ms (51.822% of one logical core)
Process working set: 87.98 MiB → 107.227 MiB
Process private memory: 50.527 MiB → 65.148 MiB
Managed process allocations: 32194848 B

| Retained observations | Samples | p50 | p95 | p99 |
| --- | ---: | ---: | ---: | ---: |
| Native paint wall time, ms | 120 | 3.576 | 5.352 | 9.879 |
| Layout wall time, ms | 120 | 0.157 | 0.343 | 0.541 |
| Framework render wall time, ms | 120 | 3.303 | 5.051 | 9.28 |
| Callback interval, ms | 119 | 30.564 | 33.017 | 40.881 |
| Native framebuffer submission wall time, ms | 120 | 0.203 | 0.293 | 0.39 |
| Managed UI-thread allocation, B | 120 | 238968 | 249432 | 362856 |
| GPU execution, ms | 0 | unavailable | unavailable | unavailable |

CollectionView: 100000 items, 120 measured offset updates of 56 logical px at a requested 16 ms interval
Viewport offset: 0 → 6720 logical px
Realized containers: 25 → 27
Container reuses in measured window: 240

Profiler phase timings are elapsed wall time. Layout and rendering can overlap other observations.
The framework render category includes software rendering and composition. Standalone raster timing is unavailable.
GDI submission is a CPU-side wall-time observation. Display-mode Hz and callback intervals do not measure scanout.
Actual compositor presentation and physical scanout are unavailable.
Raw recorder data, process counters, frame identifiers and versions are in results.json.
