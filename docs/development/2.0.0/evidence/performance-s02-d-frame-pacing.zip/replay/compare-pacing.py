from datetime import datetime, timezone
from pathlib import Path
import hashlib, json, re, shutil, subprocess, sys, threading, time
import psutil

lab, output = map(Path, sys.argv[1:])
lab = lab.resolve()
output.mkdir(parents=True)
stopped = threading.Event()
monitor = []
order = []
active = 'preflight'

def now():
    return datetime.now(timezone.utc).isoformat()

def sample():
    psutil.cpu_percent()
    while not stopped.wait(1):
        monitor.append({'utc': now(), 'cpuPercent': psutil.cpu_percent(), 'case': active})

def environment():
    power = subprocess.check_output(['powercfg','/getactivescheme']).decode(errors='replace')
    guid = re.search(r'[0-9a-fA-F]{8}-[0-9a-fA-F-]{27}', power)
    gpu=[]
    if shutil.which('nvidia-smi'):
        gpu = subprocess.check_output(['nvidia-smi','--query-gpu=name,driver_version,temperature.gpu,utilization.gpu',
                                      '--format=csv,noheader']).decode().strip().splitlines()
    return {'powerSchemeGuid':guid[0] if guid else None, 'gpuSamples':gpu}

def run(case, mode, number, warmup):
    global active
    active = f'{case}-{warmup}-{mode}-{number}'
    folder = output / active
    cli = ['dotnet', str(lab), '--scenario', case, '--backend', 'software', '--pacing', mode, '--output', str(folder.resolve())]
    if warmup:
        cli+=['--warmup-ms',str(warmup)]
    begin = now()
    with (output/(active+'.log')).open('wb') as logfile:
        subprocess.run(cli, stdout=logfile, stderr=subprocess.STDOUT, check=True, timeout=35,
                       creationflags=subprocess.CREATE_NO_WINDOW)
    result = folder / 'results.json'
    order.append({'id':active, 'scenario':case, 'mode':mode, 'trial':number, 'minimumWarmupMs':warmup,
        'startUtc':begin, 'endUtc':now(), 'sha256':hashlib.sha256(result.read_bytes()).hexdigest()})
    print(active,flush=True)

cases=[('pacing-idle',0),('virtualized-scroll',0),('pacing-animation',0),('pacing-tree',0),
       ('pacing-resize',0),('pacing-input',0),('virtualized-scroll',5000)]
worker=threading.Thread(target=sample)
worker.start()
try:
    before = environment()
    time.sleep(4.1)
    if len(monitor)<3 or sum(x['cpuPercent'] for x in monitor[-3:])/3>=20:
        raise RuntimeError(f'Host was busy before the comparison: {monitor}')
    for case_number,(case,warmup) in enumerate(cases):
        for number in range(1,4):
            modes=('reference','refresh') if (number+case_number)%2 else ('refresh','reference')
            for mode in modes:
                run(case,mode,number,warmup)
finally:
    stopped.set()
    worker.join()
    fingerprints={file.name:hashlib.sha256(file.read_bytes()).hexdigest() for file in
                  (lab,lab.with_name('ModernFormsNext.dll'),lab.with_name('SkiaSharp.dll'))}
    after = environment()
    (output/'session.json').write_text(json.dumps({'binarySha256':fingerprints,'hostCpu':monitor,'runs':order,'environmentBefore':before,'environmentAfter':after},indent=2)+'\n',encoding='utf-8')
