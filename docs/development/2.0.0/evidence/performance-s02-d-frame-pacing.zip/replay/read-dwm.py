import ctypes as c
import json,re,time
from pathlib import Path

folder=Path('artifacts/stage2-d-prep')
header=(folder/'dwmapi.h').read_text(encoding='utf-8')
assert '#include <pshpack1.h>' in header
pattern=r'typedef\s+struct _DWM_TIMING_INFO\s*\{(.*?)\}\s*DWM_TIMING_INFO'
declarations=re.search(pattern,header,re.S)[1]
class Ratio(c.Structure):
    _pack_=1
    _fields_=[('numerator',c.c_uint32),('denominator',c.c_uint32)]
widths={'UINT32':c.c_uint32,'UINT':c.c_uint32,'UNSIGNED_RATIO':Ratio,'QPC_TIME':c.c_uint64,'DWM_FRAME_COUNT':c.c_uint64,'ULONGLONG':c.c_uint64}
class DwmTiming(c.Structure):
    _pack_=1
    _fields_=[(name,widths[t]) for t,name in re.findall(r'^\s*(\w+)\s+(\w+)\s*;',declarations,re.M)]
assert DwmTiming._fields_[-1][0] == "cBuffersEmpty"
fn=c.WinDLL('dwmapi').DwmGetCompositionTimingInfo
fn.argtypes=[c.c_void_p,c.POINTER(DwmTiming)]
fn.restype=c.c_long
user=c.WinDLL('user32')
user.GetDesktopWindow.restype=c.c_void_p

def measure(handle):
    info=DwmTiming()
    info.cbSize=c.sizeof(info)
    result=fn(handle,c.byref(info))
    src={}
    if result==0:
        for name in ('qpcRefreshPeriod','qpcVBlank','qpcCompose','cFrame','cRefresh','cFrameDisplayed','qpcFrameDisplayed'):
            src[name]=getattr(info,name)
        for name in ('rateRefresh','rateCompose'):
            ratio=getattr(info,name)
            src[name]=[ratio.numerator,ratio.denominator]
    return {'scope':'global composition' if not handle else 'non-null desktop HWND probe',
            'hresult':f'0x{result & 0xffffffff:08X}','timing':src}
records=[measure(None)]
time.sleep(.1)
records.append(measure(None))
records.append(measure(user.GetDesktopWindow()))
(folder/'dwm-timing.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8')
print(records)
