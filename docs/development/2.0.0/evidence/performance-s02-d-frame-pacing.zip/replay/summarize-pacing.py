from pathlib import Path
import sys, json, statistics, collections, hashlib

out=Path(sys.argv[1])
s=json.loads((out/'session.json').read_bytes())
groups=collections.defaultdict(lambda:collections.defaultdict(list))
for row in s['runs']:
    raw=(out/row['id']/'results.json').read_bytes()
    assert hashlib.sha256(raw).hexdigest()==row['sha256']
    d=json.loads(raw)
    groups[(row['scenario'],row['minimumWarmupMs'])][row['mode']].append(d)
def summary(data):
    values=[v for v in data if v is not None]
    if not values:return None
    return {'median':round(statistics.median(values),3),'values':values}
def value(d,key,field):
    metric=d['frames'].get(key)
    return metric.get(field) if metric else None
items={}
for (case,warmup), modes in groups.items():
    entry={}
    for mode,rows in modes.items():
        batches=[d['pacing'] for d in rows]
        dist={}
        for field in ('nativePaintWallMs','frameworkRenderWallMs','layoutWallMs','callbackIntervalMs','submissionWallMs','inputDispatchWallMs','managedUiAllocationBytes'):
            dist[field]={p:summary([value(d,field,p) for d in rows]) for p in ('p50','p95','p99')}
        entry[mode]={
            'processCpuMs':summary([d['process']['totalCpuMs'] for d in rows]),
            'processWallMs':summary([d['process']['wallMs'] for d in rows]),
            'privateBytes':summary([d['process']['end']['privateBytes'] for d in rows]),
            'workingSetBytes':summary([d['process']['end']['workingSetBytes'] for d in rows]),
            'managedBytes':summary([d['process']['managedAllocatedBytes'] for d in rows]),
            'nativePaints':summary([d['frames']['sampleCount'] for d in rows]),
            'refreshHz':summary([d['environment']['reportedRefreshHz'] for d in rows]),
            'distributions':dist,
            'updates':summary([p['workloadUpdates'] for p in batches]),
            'jitMs':summary([p['measuredJitMs'] for p in batches]),
            'quietJit':[p['observedQuietJit'] for p in batches],
            'requestCounts':{f:summary([p['requests'][f] for p in batches]) for f in ('requests','signals','merged','retired','wakes')},
            'inputEnqueueToHandlerP95Ms':summary([(p.get('syntheticQueueToHandlerMs') or {}).get('p95') for p in batches]),
            'inputEnqueueToNativePaintP95Ms':summary([(p.get('inputToCompletedNativePaintMs') or {}).get('p95') for p in batches]),
            'inputCompletedSamples':summary([(p.get('inputToCompletedNativePaintMs') or {}).get('samples') for p in batches]),
        }
    items[f'{case}/{warmup}ms']=entry
(out/'summary.json').write_text(json.dumps(items,indent=2)+'\n',encoding='utf-8')
for case,entry in items.items():
    print(case)
    for mode,v in entry.items():
        fields=('processCpuMs','nativePaints','updates','jitMs','inputEnqueueToNativePaintP95Ms','inputCompletedSamples')
        print(mode, {f:v[f]['median'] if v[f] else 0 for f in fields},
              {f:x['median'] for f,x in v['requestCounts'].items()}, v['quietJit'])
