SELECT s.surface_frame_token AS input_vsync_id, s.display_frame_token,
       s.ts AS app_slice_begin_ns, s.ts + s.dur AS app_slice_end_ns,
       d.ts + d.dur AS display_slice_end_ns,
       s.present_type, s.jank_type
FROM actual_frame_timeline_slice s
LEFT JOIN actual_frame_timeline_slice d
  ON d.display_frame_token = s.display_frame_token AND d.layer_name IS NULL AND d.dur > 0
WHERE s.layer_name LIKE 'TX - com.modernformsnext.skiaqualification/com.modernformsnext.skiaqualification.QualificationActivity#%'
  AND s.dur > 0
ORDER BY s.ts
