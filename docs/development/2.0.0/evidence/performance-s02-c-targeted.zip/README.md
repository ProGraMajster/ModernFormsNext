# Targeted S02-c Windows investigation

The repeated trials in round and round-title ran one at a time with the software backend and the same .NET 10.0.15 runtime. Trace runs used separate processes.

The app-only JSON extracts retain ETW kernel CPU samples, JIT start/load events and relevant thread events. Full collector sessions contain machine-wide data and stay in the local qualification artifacts. Their SHA-256 values are in the summary.

The older EventPipe traces are separate thread-time profiles. The original topN text and actual stack observations are supplied together.

Replay source augments a copy of PerformanceLab. It expects the qualified 3x and 4x output folders and the recorded toolset. Use DiagnosticProbes-first-pass.cs with prepare-plain.py for the plain round; use DiagnosticProbes-profile.cs with prepare-profile.py for ETW, then fixture/DiagnosticProbes.cs with prepare.py for the title control.
