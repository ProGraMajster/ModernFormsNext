using System.Text.Json;
using Microsoft.Diagnostics.Tracing;
using Microsoft.Diagnostics.Tracing.Etlx;

using var log = args[0].EndsWith(".etlx", StringComparison.OrdinalIgnoreCase) ? new TraceLog(args[0]) : TraceLog.OpenOrConvert(args[0]);
var onlyPid = args.Length > 2 ? int.Parse(args[2]) : (int?)null;
var events = new Dictionary<string,int>();
var samples = new List<Sample>();
var marks = new List<Stamp>();
var jits = new List<Jit>();
foreach (var ev in log.Events)
{
    if (onlyPid is int pid && ev.ProcessID != pid) continue;
    string name = ev.ProviderName + "/" + ev.EventName;
    events[name] = events.GetValueOrDefault(name) + 1;

    bool stackSample = ev.ProviderName.Contains("SampleProfiler", StringComparison.OrdinalIgnoreCase)
        || ev.EventName is "PerfInfo/Sample" or "PerfInfo/SampledProfile";
    if (stackSample)
    {
        List<Frame> frames = new();
        for (var stack = ev.CallStack(); stack is not null; stack = stack.Caller)
        {
            var addr = stack.CodeAddress;
            frames.Add(new(addr.FullMethodName, addr.ModuleFile?.Name ?? "", addr.Address));
        }
        var metadata = ev.PayloadNames.Select(key => key + "=" + ev.PayloadByName(key)).ToArray();
        samples.Add(new(ev.TimeStampRelativeMSec, ev.TimeStamp.ToUniversalTime(), ev.ProcessID, ev.ThreadID, ev.EventName, metadata, frames));
    }
    else if (ev.EventName.StartsWith("GC/", StringComparison.Ordinal) || ev.EventName.Contains("Thread", StringComparison.Ordinal)
             || ev.ProviderName == "ModernFormsNext-S02c-Probe")
    {
        var metadata = ev.PayloadNames.Select(key => key + "=" + ev.PayloadByName(key)).ToArray();
        marks.Add(new(ev.TimeStampRelativeMSec, ev.TimeStamp.ToUniversalTime(), ev.ThreadID, name, metadata));
    }
    else if (ev.EventName.StartsWith("Method/JittingStarted", StringComparison.Ordinal)
             || ev.EventName.StartsWith("Method/LoadVerbose", StringComparison.Ordinal))
    {
        var method = ev.PayloadByName("MethodNamespace") + "." + ev.PayloadByName("MethodName");
        jits.Add(new(ev.TimeStampRelativeMSec, ev.ThreadID, name, method, Convert.ToInt64(ev.PayloadByName("MethodID"))));
    }
}
using var output = File.Create(args[1]);
JsonSerializer.Serialize(output, new { events, samples, marks, jits });

sealed record Frame(string Method, string Module, ulong Address);
sealed record Sample(double Ms, DateTime Utc, int Pid, int Tid, string Name, string[] Metadata, List<Frame> Frames);
sealed record Stamp(double Ms, DateTime Utc, int Tid, string Name, string[] Metadata);
sealed record Jit(double Ms, int Tid, string Name, string Method, long Id);
