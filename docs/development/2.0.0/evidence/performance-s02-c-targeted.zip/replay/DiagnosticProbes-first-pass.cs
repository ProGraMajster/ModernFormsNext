using System.Diagnostics;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text.Json;
using IOPath = System.IO.Path;
using SkiaSharp;
using Topten.RichTextKit;

namespace ModernFormsNext.PerformanceLab;

// Reuses the PerformanceLab runner, its first native paint detection and its startup workload.
internal sealed class DiagnosticStartup(string kind) : BenchmarkScenario
{
    internal override string Id => "diagnostic-" + kind;
    internal override string WorkloadVersion => "s02c-first-paint-isolation-v1";

    internal override Control CreateContent()
    {
        if (kind == "empty")
            return new Panel { Dock = DockStyle.Fill };
        if (kind == "geometry")
            return new GeometryImage { Dock = DockStyle.Fill };

        var panel = new FlowLayoutPanel { Dock = DockStyle.Fill };
        panel.SuspendLayout();
        int count = kind == "labels-with-text" ? 24 : 96;
        for (int index = 0; index < count; index++)
        {
            Control child = kind != "labels-with-text" && index % 4 == 0 ? new Button() : new Label();
            child.Text = kind == "labels-with-text" ? FormattableString.Invariant($"Field {index:D2}") : "";
            child.Size = new Size(140, 28);
            panel.Controls.Add(child);
        }
        panel.ResumeLayout();
        return panel;
    }

    internal override void Begin(BenchmarkRun run) => run.Complete();

    private sealed class GeometryImage : Control
    {
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            using var bitmap = SKBitmap.Decode(Convert.FromBase64String("iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAIAAABvFaqvAAAAd0lEQVR4nGNUCq5koAZgooopDIPRIBY8cifKv6KJWHRyk+wiTFMYcAjidBEe1QwwWUyn0SywT+B1Dh5lTGSYglXx4EtHTCPEIAvcOQAToClGdxGRZlnQLmWz4LINV+K0wOFknC7CqsECt8fxlUckhT0T8UqHmkEA7kgf8u6mxbMAAAAASUVORK5CYII="))
                ?? throw new InvalidOperationException("The diagnostic PNG did not decode.");
            using var image = SKImage.FromBitmap(bitmap);
            using var paint = new SKPaint { Color = SKColors.Teal, IsAntialias = true };
#if SKIA4
            using var builder = new SKPathBuilder();
            builder.AddRoundRect(new SKRect(2, 2, 55, 22), 5, 5);
            using var path = builder.Detach();
#else
            using var path = new SKPath();
            path.AddRoundRect(new SKRect(2, 2, 55, 22), 5, 5);
#endif
            for (int i = 0; i < 96; i++)
            {
                e.Canvas.Save();
                e.Canvas.Translate((i % 12) * 75, (i / 12) * 38);
                e.Canvas.DrawPath(path, paint);
                e.Canvas.DrawImage(image, new SKRect(4, 4, 18, 18));
                e.Canvas.Restore();
            }
        }
    }
}

internal static class DependencyProbe
{
    internal static int Run(string kind, string path)
    {
        var passes = new List<List<OperationTime>>();
        for (int pass = 0; pass < 2; pass++)
        {
            var operations = new List<OperationTime>();
            switch (kind)
            {
                case "skia": Raster(operations); break;
                case "font": Typeface(operations); break;
                case "harfbuzz": Shape(operations); break;
                case "rich": RichText(operations); break;
                default: throw new ArgumentOutOfRangeException(nameof(kind));
            }
            passes.Add(operations);
        }
        File.WriteAllText(path, JsonSerializer.Serialize(new { kind, passes,
            runtime = RuntimeInformation.FrameworkDescription, skia = typeof(SKCanvas).Assembly.GetName().Version?.ToString(),
            harfBuzz = typeof(HarfBuzzSharp.Font).Assembly.GetName().Version?.ToString(),
            rich = typeof(TextBlock).Assembly.GetName().Version?.ToString() }));
        return 0;
    }

    // NOINLINE keeps each first-touch call and its first-use JIT inside the timed region.
    [MethodImpl(MethodImplOptions.NoInlining)]
    private static void Raster(List<OperationTime> time)
    {
        var start = Stopwatch.GetTimestamp();
        var native = SkiaSharpVersion.Native;
        time.Add(new("native-load-and-version", Stopwatch.GetElapsedTime(start).TotalMilliseconds, native.ToString()));
        start = Stopwatch.GetTimestamp();
        using var surface = SKSurface.Create(new SKImageInfo(960, 640));
        time.Add(new("surface-create", Stopwatch.GetElapsedTime(start).TotalMilliseconds, null));
        start = Stopwatch.GetTimestamp();
        var canvas = surface.Canvas;
        canvas.Clear(SKColors.White);
        time.Add(new("canvas-first-clear", Stopwatch.GetElapsedTime(start).TotalMilliseconds, null));
        start = Stopwatch.GetTimestamp();
        using var paint = new SKPaint { Color = SKColors.Teal, IsAntialias = true };
        time.Add(new("paint-create", Stopwatch.GetElapsedTime(start).TotalMilliseconds, null));
        start = Stopwatch.GetTimestamp();
#if SKIA4
        using var builder = new SKPathBuilder();
        builder.AddRoundRect(new SKRect(1, 1, 55, 22), 5, 5);
        using var path = builder.Detach();
#else
        using var path = new SKPath();
        path.AddRoundRect(new SKRect(1, 1, 55, 22), 5, 5);
#endif
        time.Add(new("path-create", Stopwatch.GetElapsedTime(start).TotalMilliseconds, null));
        start = Stopwatch.GetTimestamp();
        canvas.DrawPath(path, paint);
        canvas.Flush();
        time.Add(new("draw-path-flush", Stopwatch.GetElapsedTime(start).TotalMilliseconds, null));
    }

    [MethodImpl(MethodImplOptions.NoInlining)]
    private static void Typeface(List<OperationTime> time)
    {
        var start = Stopwatch.GetTimestamp();
        var manager = SKFontManager.Default;
        time.Add(new("font-manager-first-touch", Stopwatch.GetElapsedTime(start).TotalMilliseconds, null));
        start = Stopwatch.GetTimestamp();
        using var face = manager.MatchFamily("Segoe UI", SKFontStyle.Normal);
        time.Add(new("match-segoe", Stopwatch.GetElapsedTime(start).TotalMilliseconds, face.FamilyName));
    }

    [MethodImpl(MethodImplOptions.NoInlining)]
    private static void Shape(List<OperationTime> time)
    {
        var fontPath = IOPath.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Fonts), "segoeui.ttf");
        var start = Stopwatch.GetTimestamp();
        using var blob = HarfBuzzSharp.Blob.FromFile(fontPath);
        using var face = new HarfBuzzSharp.Face(blob, 0);
        using var font = new HarfBuzzSharp.Font(face);
        font.SetFunctionsOpenType();
        time.Add(new("harfbuzz-font-and-file", Stopwatch.GetElapsedTime(start).TotalMilliseconds, null));
        start = Stopwatch.GetTimestamp();
        using var buffer = new HarfBuzzSharp.Buffer();
        buffer.AddUtf16("Field 01");
        buffer.GuessSegmentProperties();
        font.Shape(buffer);
        time.Add(new("first-shape", Stopwatch.GetElapsedTime(start).TotalMilliseconds, buffer.Length.ToString()));
    }

    [MethodImpl(MethodImplOptions.NoInlining)]
    private static void RichText(List<OperationTime> time)
    {
        // Surface setup is intentionally separate. It would otherwise dominate the first text paint interval.
        var start = Stopwatch.GetTimestamp();
        using var surface = SKSurface.Create(new SKImageInfo(960, 640));
        time.Add(new("rich-surface", Stopwatch.GetElapsedTime(start).TotalMilliseconds, null));
        start = Stopwatch.GetTimestamp();
        var block = new TextBlock();
        block.AddText("Field 01", new Style { FontFamily = "Segoe UI", FontSize = 14, TextColor = SKColors.Black });
        time.Add(new("rich-block", Stopwatch.GetElapsedTime(start).TotalMilliseconds, null));
        start = Stopwatch.GetTimestamp();
        var width = block.MeasuredWidth;
        time.Add(new("rich-measure-layout-first-shape", Stopwatch.GetElapsedTime(start).TotalMilliseconds,
            width.ToString(System.Globalization.CultureInfo.InvariantCulture)));
        start = Stopwatch.GetTimestamp();
        block.Paint(surface.Canvas, new SKPoint(0, 0), new TextPaintOptions { Edging = SKFontEdging.SubpixelAntialias });
        surface.Canvas.Flush();
        time.Add(new("rich-paint-flush", Stopwatch.GetElapsedTime(start).TotalMilliseconds, null));
    }

    private sealed record OperationTime(string Name, double Ms, string? Observation);
}

internal static class ThreadCpuProbe
{
    private static readonly List<ThreadSnapshot> Snapshots = new List<ThreadSnapshot>(4);

    internal static void Mark(string phase)
    {
        int uiThread = GetCurrentThreadId();
        var stamp = DateTimeOffset.UtcNow;
        using var process = Process.GetCurrentProcess();
        var cpuTimes = new List<CpuTime>();
        foreach (ProcessThread thread in process.Threads)
        {
            using (thread)
            {
                var handle = OpenThread(0x0800, false, thread.Id);
                if (handle == IntPtr.Zero) continue;
                try
                {
                    if (!GetThreadTimes(handle, out long creation, out _, out long kernel, out long user)) continue;
                    string description = "";
                    if (GetThreadDescription(handle, out IntPtr text) == 0 && text != IntPtr.Zero)
                    {
                        try { description = Marshal.PtrToStringUni(text) ?? ""; }
                        finally { LocalFree(text); }
                    }
                    cpuTimes.Add(new(thread.Id, creation, user / 10000.0, kernel / 10000.0, description));
                }
                finally { CloseHandle(handle); }
            }
        }
        Snapshots.Add(new(phase, stamp, uiThread, process.TotalProcessorTime.TotalMilliseconds, cpuTimes));
    }

    internal static void Save(string path) => File.WriteAllText(path, JsonSerializer.Serialize(Snapshots));

    private sealed record CpuTime(int Id, long Creation, double UserMs, double KernelMs, string Label);
    private sealed record ThreadSnapshot(string Phase, DateTimeOffset Utc, int UiThread, double ProcessMs, List<CpuTime> Threads);

    [DllImport("kernel32")] private static extern int GetCurrentThreadId();
    [DllImport("kernel32")] private static extern IntPtr OpenThread(uint access, bool inherit, int id);
    [DllImport("kernel32")] [return:MarshalAs(UnmanagedType.Bool)]
    private static extern bool GetThreadTimes(IntPtr handle, out long creation, out long exit, out long kernel, out long user);
    [DllImport("kernel32")] private static extern uint GetThreadDescription(IntPtr handle, out IntPtr text);
    [DllImport("kernel32")] private static extern IntPtr LocalFree(IntPtr memory);
    [DllImport("kernel32")] [return:MarshalAs(UnmanagedType.Bool)] private static extern bool CloseHandle(IntPtr handle);
}

