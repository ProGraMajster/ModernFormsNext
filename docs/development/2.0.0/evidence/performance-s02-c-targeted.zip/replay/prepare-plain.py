from pathlib import Path
import os
import shutil
import subprocess

root = Path('artifacts/stage2-c').resolve()
out = root / 'targeted-performance'
fixture = out / 'fixture'
src = Path('samples/ModernFormsNext.PerformanceLab')
for name in ('BenchmarkRun', 'BenchmarkMeasurements', 'BenchmarkReport', 'Program', 'Scenarios', 'WindowsEnvironment'):
    source = (src / (name + '.cs')).read_text(encoding='utf-8-sig')
    if name == 'Program':
        source = source.replace('long enteredMain = Stopwatch.GetTimestamp();', '''long enteredMain = Stopwatch.GetTimestamp();
        if (args is ["--dependency", var dependency, var resultPath])
            return DependencyProbe.Run(dependency, resultPath);''')
        source = source.replace('BenchmarkReport.Save(options.Output, result);', '''BenchmarkReport.Save(options.Output, result);
            if (options.Scenario is VirtualizedScrollScenario)
                ThreadCpuProbe.Save(IOPath.Combine(options.Output, "threads.json"));''')
        source = source.replace('"startup" => new StartupScenario(),', '''"startup" => new StartupScenario(),
            "empty" or "labels-without-text" or "labels-with-text" or "geometry" => new DiagnosticStartup(arguments["--scenario"]),''')
    if name == 'BenchmarkRun':
        source = source.replace('internal void BeginMeasurement()\n    {', 'internal void BeginMeasurement()\n    {\n        ThreadCpuProbe.Mark("scroll-start");')
        source = source.replace('var measuredEnd = ProcessSample.Capture(process);', '''var measuredEnd = ProcessSample.Capture(process);
        if (scroll is not null) ThreadCpuProbe.Mark("scroll-end");''')
    (fixture/(name+'.cs')).write_text(source, encoding='utf-8')
for leg in ('3x', '4x'):
    original = root / 'benchmark-pair' / leg
    target = out / 'bin' / leg
    target.mkdir(parents=True, exist_ok=True)
    for file in original.rglob('*'):
        if not file.is_file() or (file.parts[len(original.parts)] == 'runtimes' and 'win-x64' not in file.parts and 'win' not in file.parts):
            continue
        relative = file.relative_to(original)
        copy = target / relative
        if not copy.exists():
            copy.parent.mkdir(parents=True, exist_ok=True)
            os.link(file, copy)
    with (out / f'compile-{leg}.log').open('w') as log:
        subprocess.run(['dotnet','build',str(fixture/'Probe.csproj'),'-c','Release','-o',str(out/'build'/leg),'-m:1',
                        '-p:UseSharedCompilation=false',f'-p:Leg={leg}',f'-p:StackPath={original}'],
                       stdout=log,stderr=subprocess.STDOUT,check=True)
    shutil.copy2(out/'build'/leg/'Probe.dll',target/'Probe.dll')
