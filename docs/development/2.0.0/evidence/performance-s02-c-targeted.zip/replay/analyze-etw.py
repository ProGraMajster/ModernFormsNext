from collections import Counter, defaultdict
from datetime import datetime, timedelta, timezone
from pathlib import Path
from zipfile import ZipFile
import hashlib
import json
import re
import shutil
import subprocess

root = Path('artifacts/stage2-c/targeted-performance')
profiles = root/'profiles'
reader = root/'trace-reader/bin/Release/net10.0/TraceReader.dll'
utc_epoch = datetime(1,1,1,tzinfo=timezone.utc)

def read_json(path):
    return json.loads(path.read_bytes())

def instant(value):
    return datetime.fromisoformat(re.sub(r"\.(\d+)", lambda m: "." + m[1].ljust(6,"0")[:6], value.replace("Z", "+00:00")))

def increment(counter, label):
    counter[label] += 1

def name(module):
    return module.rsplit('\\',1)[-1]

def group(method):
    for part in ('SkiaSharp', 'HarfBuzzSharp', 'Topten.RichTextKit', 'ModernFormsNext'):
        if method.startswith(part + '.'):
            return part
    return 'runtime/other'

def phase_for(sample, phases):
    for phase, begin, end in phases:
        if begin <= sample < end:
            return phase
    return 'outside'

def classify_stack(frames):
    text = ' '.join(f['Method'] for f in frames)
    if 'InitializeTlsBucketsAndTrimming' in text or 'GC.RunFinalizers' in text:
        return 'finalization'
    if 'HarfBuzzSharp.' in text or 'Topten.RichTextKit.' in text:
        return 'text'
    if 'DoPaint(' in text or '.RaisePaint(' in text or 'WndProc' in text and 'DrawDamageToDevice' in text:
        return 'render'
    if 'Dispatcher' in text:
        return 'dispatcher (inclusive)'
    return 'other'

summaries={}
for archive in sorted(profiles.glob('*.diagsession')):
    key=archive.stem
    run=profiles/key
    clk=read_json(run/'profile-clock.json')
    data=read_json(run/'results.json')
    raw=profiles/(key+'.etl')
    summary=profiles/(key+'-app-trace.json')
    if not raw.exists():
        with ZipFile(archive) as zipped:
            members = [n for n in zipped.namelist() if n.endswith('.etl')]
            assert len(members)==1
            with zipped.open(members[0]) as incoming, raw.open('wb') as target:
                shutil.copyfileobj(incoming,target)
    subprocess.run(['dotnet',str(reader),str(raw),str(summary),str(clk['processId'])],check=True)
    parsed=read_json(summary)
    main=utc_epoch + timedelta(microseconds=clk['utcTicksAtMain']//10)
    first_paint=main+timedelta(milliseconds=data['startup']['mainToFirstCompletePaintEstimateMs'])
    frame=next(f for f in data['recorder']['frames'] if f['sequence']==data['startup']['firstCompletePaintSequence'])
    hours, minutes, seconds = map(float, frame['duration'].split(':'))
    duration = 1000 * (3600 * hours + 60 * minutes + seconds)
    start_paint=first_paint-timedelta(milliseconds=duration)
    phases=[('first-paint',start_paint,first_paint),('Main-before-paint',main,start_paint)]
    if (run/'threads.json').is_file():
        thread=read_json(run/'threads.json')
        a,b=(instant(t['Utc']) for t in thread)
        phases.extend([('scroll-measured',a,b),('scroll-warmup',first_paint,a)])
    samples=defaultdict(lambda:defaultdict(lambda:{'leafModules':Counter(),'managedStackKinds':Counter(),'samples':0}))
    for sample in parsed['samples']:
        phase=phase_for(instant(sample['Utc']),phases)
        scope='UI' if sample['Tid']==clk['uiTid'] else str(sample['Tid'])
        bucket=samples[phase][scope]
        bucket['samples']+=1
        frames=sample['Frames']
        increment(bucket['leafModules'],name(frames[0]['Module']) if frames and frames[0]['Module'] else '(unresolved)')
        increment(bucket['managedStackKinds'],classify_stack(frames))
    starts={}
    jit=defaultdict(lambda:defaultdict(lambda:defaultdict(lambda:{'completed':0,'wallMs':0.0})))
    trace_origin = instant(parsed['samples'][0]['Utc']) - timedelta(milliseconds=parsed['samples'][0]['Ms'])
    for entry in parsed['jits']:
        k=(entry['Tid'],entry['Id'])
        utc=trace_origin+timedelta(milliseconds=entry['Ms'])
        if 'JittingStarted' in entry['Name']:
            starts[k]=entry['Ms']
        elif k in starts:
            start=starts.pop(k)
            began=trace_origin+timedelta(milliseconds=start)
            phase=phase_for(began,phases)
            thread='UI' if entry['Tid']==clk['uiTid'] else str(entry['Tid'])
            b=jit[phase][thread][group(entry['Method'])]
            b['completed']+=1
            b['wallMs']+=entry['Ms']-start
    summaries[key]={
        'traceSha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
        'startUtc':main.isoformat(),
        'scope':[{'name':p,'beginUtc':b.isoformat(),'endUtc':e.isoformat()} for p,b,e in phases],
        'firstPaintMs':duration,'threads':samples,'jitStartToLoad':jit,
        'filteredEvents':parsed['events'],
        'threadEvents':[m for m in parsed['marks'] if any(g in m['Name'] for g in ('Thread/SetName','GC/Start','GC/Stop','GC/Suspend','GC/Restart'))],
    }
(profiles/'native-summary.json').write_text(json.dumps(summaries,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print(list(summaries))
