from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import subprocess
import threading
import time
import psutil

root = Path('artifacts/stage2-c/targeted-performance').resolve()
out = root / 'round-title'
out.mkdir()
epoch = time.monotonic()
stopped = threading.Event()
order = []
telemetry = []
phase = 'idle-check'

def now():
    return datetime.now(timezone.utc).isoformat()

def observe():
    psutil.cpu_percent()
    while not stopped.wait(1.0):
        telemetry.append({'utc':now(), 'cpuPct':psutil.cpu_percent(), 'phase':phase})

def run(leg, group, scenario, trial):
    global phase
    phase = f'{group}-{scenario}-{trial}-{leg}'
    folder = root/'bin'/leg
    prefix = ['dotnet','exec','--depsfile',str(folder/'ModernFormsNext.PerformanceLab.deps.json'),
              '--runtimeconfig',str(folder/'ModernFormsNext.PerformanceLab.runtimeconfig.json'),str(folder/'Probe.dll')]
    destination = out / phase
    if group == 'unit':
        destination = destination.with_suffix('.json')
        args = ['--dependency',scenario,str(destination)]
    else:
        args = ['--scenario',scenario,'--backend','software','--output',str(destination)]
    started = now()
    with (out/(phase+'.log')).open('w') as log:
        subprocess.run(prefix+args, stdout=log, stderr=subprocess.STDOUT, check=True, timeout=35,
                       creationflags=subprocess.CREATE_NO_WINDOW)
    result = destination if group == 'unit' else destination/'results.json'
    order.append({'trial':trial,'group':group,'scenario':scenario,'stack':leg,'path':result.relative_to(out).as_posix(),
                  'startUtc':started,'endUtc':now(),'sha256':hashlib.sha256(result.read_bytes()).hexdigest()})
    print(phase,flush=True)

monitor = threading.Thread(target=observe)
monitor.start()
try:
    time.sleep(4.1)
    recent = telemetry[-3:]
    if len(recent) < 3 or sum(s['cpuPct'] for s in recent)/len(recent) >= 20:
        raise RuntimeError(f'Host load during idle check: {recent}')
    groups = [('paint',('empty','empty-without-title')),
              ('unit',('skia-title','rich-title'))]
    for group, cases in groups:
        for trial in range(1,4):
            for index, scenario in enumerate(cases):
                legs = ('3x','4x') if (trial+index)%2==1 else ('4x','3x')
                for leg in legs:
                    run(leg,group,scenario,trial)
finally:
    stopped.set()
    monitor.join()
    (out/'telemetry.json').write_text(json.dumps(telemetry,indent=2)+'\n',encoding='utf-8')
    (out/'order.json').write_text(json.dumps(order,indent=2)+'\n',encoding='utf-8')

