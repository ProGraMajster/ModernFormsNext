from pathlib import Path
import json, statistics
root=Path('artifacts/stage2-c/targeted-performance')/'round'
order=json.loads((root/'order.json').read_bytes())
def med(v): return round(statistics.median(v),2)
def stat(v): return [round(n,2) for n in v]
scenarios={}
for row in order:
    case=(row['group'],row['scenario'])
    scenarios.setdefault(case,{}).setdefault(row['stack'],[]).append(root/row['path'])
for (group,case),legs in scenarios.items():
    print(case)
    for leg,files in legs.items():
        rows=[json.loads(p.read_bytes()) for p in files]
        if group=='paint':
            data={}
            for row in rows:
                startup=row['startup']
                f=next(f for f in row['recorder']['frames'] if f['sequence']==startup['firstCompletePaintSequence'])
                metrics={'shown':startup['mainToShownMs'],'first':startup['mainToFirstCompletePaintEstimateMs'],
                         'native':row['frames']['nativePaintWallMs']['p50'],'render':row['frames']['frameworkRenderWallMs']['p50'],
                         'layout':row['frames']['layoutWallMs']['p50']}
                for k,v in metrics.items():data.setdefault(k,[]).append(v)
            print(leg,{k:(med(v),stat(v)) for k,v in data.items()})
        elif group=='unit':
            print(leg, {o['Name']:[med([row['passes'][i][j]['Ms'] for row in rows]) for i in (0,1)] for j,o in enumerate(rows[0]['passes'][0])})
        else:
            for result,f in zip(rows,files):
                a,b=json.loads((f.parent/'threads.json').read_bytes())
                lookup={(t['Id'],t['Creation']):t for t in a['Threads']}
                totals=[]
                for t in b['Threads']:
                    old=lookup.get((t['Id'],t['Creation']),{'UserMs':0, 'KernelMs':0})
                    cpu=(t['UserMs']-old['UserMs'],t['KernelMs']-old['KernelMs'])
                    if sum(cpu) or t['Id']==b['UiThread'] or 'Finalizer' in t['Label']:
                        totals.append(('UI' if t['Id']==b['UiThread'] else t['Label'],stat(cpu)))
                print(leg,result['process']['totalCpuMs'],b['ProcessMs']-a['ProcessMs'],totals,'frame p50=',result['frames']['nativePaintWallMs']['p50'])
